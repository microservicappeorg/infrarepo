terraform {

  backend "s3" {

  bucket = "ecommerce-tfstate-dev"
  
  key = "dev/vpc.tfstate"
  
  region = "us-east-1"
}
}