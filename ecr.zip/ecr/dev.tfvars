
ecr_repository_names = [
    "ecrrepo-1",
    "ecrrepo-2",
    "ecrrepo-3"
]

repository_image_scan_on_push = true
repository_force_delete = false
repository_image_tag_mutability = "IMMUTABLE"

tags = {
    terraform = "true"
    environment = "dev"
}

aws_region = "us-east-1"
    