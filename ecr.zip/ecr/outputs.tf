output "repository_urls" {
  description = "URLs of the ECR repositories"

  value = {
    for name, repo in module.ecr :
    name => repo.repository_url
  }
}

output "repository_arns" {
  description = "ARNs of the ECR repositories"

  value = {
    for name, repo in module.ecr :
    name => repo.repository_arn
  }
}

output "repository_names" {
  description = "Names of the ECR repositories"

  value = {
    for name, repo in module.ecr :
    name => repo.repository_name
  }
}