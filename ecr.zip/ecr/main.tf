module "ecr" {

  source = "../../../modules/ecr"

  for_each = toset(var.ecr_repository_names)

  repository_name = each.value

 
 repository_image_scan_on_push = var.repository_image_scan_on_push
 repository_force_delete         = var.repository_force_delete
 repository_image_tag_mutability = var.repository_image_tag_mutability

  tags = var.tags
}