module "ecr" {

  source = "terraform-aws-modules/ecr/aws"

  

  repository_name = var.repository_name

 
 repository_image_scan_on_push = var.repository_image_scan_on_push
 repository_force_delete         = var.repository_force_delete
 repository_image_tag_mutability = var.repository_image_tag_mutability

 create_lifecycle_policy = false

  tags = var.tags
}