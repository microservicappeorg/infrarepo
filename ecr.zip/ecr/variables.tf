variable "ecr_repository_names" {
    type = list(string)
}

variable "repository_image_scan_on_push" {
    type = bool

}

variable "repository_force_delete" {
    type = bool
}

variable "repository_image_tag_mutability" {
    type = string
}

variable "tags" {
    type = map(string)
}

variable "aws_region" {
    type = string
}