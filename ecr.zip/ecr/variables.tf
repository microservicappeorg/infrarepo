variable "repository_name" {
    type = string
}

variable "repository_image_scan_on_push" {
    type = bool

}

variable "repository_force_delete" {
    type = bool
}

variable "repository_image_tag_mutability" {
    type = string
}

variable "tags" {
    type = map(string)
}