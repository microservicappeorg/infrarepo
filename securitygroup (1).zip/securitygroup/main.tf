module "security_group" {
  source = "../../../modules/securitygroup"

  for_each = var.security_groups
  name = each.value.name
  description = each.value.description
  vpc_id = var.vpc_id
  tags = var.tags
}