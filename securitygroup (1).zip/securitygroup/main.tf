module "security_group" {
  source = "terraform-aws-modules/security-group/aws"

  name        = var.name
  description = "this security group is beig created for the respective aws resources "
  vpc_id      = var.vpc_id



  tags = var.tags
}