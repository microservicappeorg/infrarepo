output "security_group_ids" {
  description = "IDs of the security groups"

  value = {
    for name, sg in module.security_group :
    name => sg.security_group_id
  }
}

output "security_group_arns" {
  description = "ARNs of the security groups"

  value = {
    for name, sg in module.security_group :
    name => sg.security_group_arn
  }
}

output "security_group_names" {
  description = "Names of the security groups"

  value = {
    for name, sg in module.security_group :
    name => sg.security_group_name
  }
}

output "security_group_vpc_ids" {
  description = "VPC IDs of the security groups"

  value = {
    for name, sg in module.security_group :
    name => sg.security_group_vpc_id
  }
}