

security_groups = {
    alb = {
        name = "alb-sg"
        description = "this is alb sg "
    }

    ecs = {
        name = "ecs-sg"
        description = " this is ecs sg"
    }
}

vpc_id = "vpc-039441fc01847295f"

tags = {
    environment = "dev"
    terraform = "true"
}


aws_region = "us-east-1"