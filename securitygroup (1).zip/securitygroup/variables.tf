variable "security_groups" {

type = map(object({

name = string
description = string


}))


}

variable "vpc_id" {

type = string

}


variable "tags" {

type = map(string)

}

variable "aws_region" {
type = string
}