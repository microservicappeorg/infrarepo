
variable "name" {

description = "the name of the security group to be created "
type = string

}

variable "description"{
description = " this is to enter description for the sg"
type = string
}

variable "vpc_id" {
description = " the vpc to be used"
type = string 
}

variable "tags" {
description = " details of the tags"
type = map(string)
}
                                                                                                    