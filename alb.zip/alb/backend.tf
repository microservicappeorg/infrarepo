terraform {
  backend "s3" {
    bucket = "ecommerce-tfstate-dev"
    key    = "dev/alb/terraform.tfstate"
    region = "us-east-1"
    use_lockfile = true
  }
}