output "alb_arn" {
  description = "ARN of the Application Load Balancer"
  value       = module.alb.arn
}

output "alb_dns_name" {
  description = "DNS name of the Application Load Balancer"
  value       = module.alb.dns_name
}

output "alb_id" {
  description = "ID of the Application Load Balancer"
  value       = module.alb.id
}

output "target_groups" {
  description = "Target groups created by the ALB"
  value       = module.alb.target_groups
}