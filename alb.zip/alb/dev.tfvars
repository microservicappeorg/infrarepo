aws_region = "us-east-1"

alb_name = "dev-alb"

vpc_id = "vpc-039441fc01847295f"

enable_https    = false
certificate_arn = null

subnets = [
  "subnet-0fea456946779218d",
  "subnet-0e68e67cfc49d59f8"
  
]

security_groups = [
  "sg-0ffd41a6873c7f263"
]

enable_deletion_protection = false

listeners = {
  http = {
    port     = 80
    protocol = "HTTP"

    forward = {
      target_group_key = "ecs"
    }
  }
}

target_groups = {
  ecs = {
    name_prefix = "dev-"
    protocol    = "HTTP"
    port        = 8080
    target_type = "ip"
    create_attachment = false

    health_check = {
      enabled  = true
      path     = "/health"
      protocol = "HTTP"
      port     = "traffic-port"
    }
  }
}

tags = {
  Environment = "dev"
  ManagedBy   = "Terraform"
}