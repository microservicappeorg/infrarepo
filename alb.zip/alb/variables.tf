variable "aws_region" {
  description = "AWS region where the ALB will be created"
  type        = string
}

variable "alb_name" {
  description = "Name of the Application Load Balancer"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC where the ALB will be created"
  type        = string
}

variable "subnets" {
  description = "Public subnet IDs where the ALB will be placed"
  type        = list(string)
}

variable "security_groups" {
  description = "Security group IDs to attach to the ALB"
  type        = list(string)
}

variable "enable_deletion_protection" {
  description = "Whether deletion protection is enabled for the ALB"
  type        = bool
  default     = false
}

variable "listeners" {
  description = "ALB listener configuration"
  type        = any
}

variable "target_groups" {
  description = "ALB target group configuration"
  type        = any
}

variable "tags" {
  description = "Tags to apply to ALB resources"
  type        = map(string)
  default     = {}
}

variable "certificate_arn" {
  description = "ARN of the ACM certificate used for HTTPS"
  type        = string
  default     = null
}


variable "enable_https" {
  description = "Whether to enable HTTPS listener on the ALB"
  type        = bool
  default     = false
}