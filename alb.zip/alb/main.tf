module "alb" {
  source = "../../../modules/alb"

  name = var.alb_name

  vpc_id          = var.vpc_id
  subnets         = var.subnets
  security_groups = var.security_groups

  enable_deletion_protection = var.enable_deletion_protection

  listeners     = var.listeners
  target_groups = var.target_groups

  certificate_arn = var.certificate_arn
  enable_https    = var.enable_https

  tags = var.tags
}