module "alb" {
  source  = "terraform-aws-modules/alb/aws"
  version = "10.5.0"

  name               = var.name
  load_balancer_type = "application"

  vpc_id          = var.vpc_id
  subnets         = var.subnets
  security_groups = var.security_groups

  enable_deletion_protection = var.enable_deletion_protection

  create_security_group = false

  listeners = merge(
    var.listeners,

    var.enable_https ? {
      https = {
        port            = 443
        protocol        = "HTTPS"
        certificate_arn = var.certificate_arn

        forward = {
          target_group_key = "ecs"
        }
      }
    } : {}
  )

  target_groups = var.target_groups

  tags = var.tags
}