aws_region = "ap-south-1"

bucket_name = "my-app-dev-s3-bucket"

environment = "dev"

application_name = "my-app"

versioning_enabled = true

sse_algorithm = "AES256"

lifecycle_enabled = true

expiration_days = 365