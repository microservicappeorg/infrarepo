module "s3" {
  source = "./modules/s3"

  bucket_name = var.bucket_name

  versioning_enabled = var.versioning_enabled

  sse_algorithm = var.sse_algorithm

  lifecycle_enabled = var.lifecycle_enabled
  expiration_days   = var.expiration_days

  tags = {
    Environment = var.environment
    Application = var.application_name
    ManagedBy   = "Terraform"
  }
}