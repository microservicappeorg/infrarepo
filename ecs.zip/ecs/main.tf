module "ecs_cluster" {
  source  = "terraform-aws-modules/ecs/aws//modules/cluster"
  version = "7.6.0"

  name = var.cluster_name

  cluster_capacity_providers = ["FARGATE"]

  default_capacity_provider_strategy = {
    FARGATE = {
      weight = 100
    }
  }

  tags = var.tags
}

module "ecs_service" {
  for_each = var.services

  source  = "terraform-aws-modules/ecs/aws//modules/service"
  version = "7.6.0"

  name        = each.value.name
  cluster_arn = module.ecs_cluster.arn

  cpu           = each.value.cpu
  memory        = each.value.memory
  desired_count = each.value.desired_count

  launch_type = "FARGATE"

  subnet_ids         = each.value.subnet_ids
  security_group_ids = each.value.security_group_ids

  # IAM roles
  task_exec_iam_role_arn = each.value.task_exec_iam_role_arn
  tasks_iam_role_arn      = try(each.value.task_iam_role_arn, null)

  # Container definition
  container_definitions = {
    (each.value.container_name) = {
      image = each.value.container_image

      cpu    = each.value.cpu
      memory = each.value.memory

      essential = true

      portMappings = [
        {
          containerPort = each.value.container_port
          protocol      = "tcp"
        }
      ]
    }
  }

  # ALB → Target Group → ECS task
  load_balancer = {
    service = {
      target_group_arn = each.value.target_group_arn
      container_name   = each.value.container_name
      container_port   = each.value.container_port
    }
  }

  tags = var.tags
}