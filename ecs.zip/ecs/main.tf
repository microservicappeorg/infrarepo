module "ecs" {
  source = "../../../modules/ecs"

  cluster_name = var.cluster_name
  services     = var.services
  tags         = var.tags
}