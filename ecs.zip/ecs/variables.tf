variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "cluster_name" {
  description = "Name of the ECS cluster"
  type        = string
}

variable "services" {
  description = "ECS services to create"

  type = map(object({
    name                       = string
    cpu                        = number
    memory                     = number
    desired_count              = number
    container_name             = string
    container_image            = string
    container_port             = number
    subnet_ids                 = list(string)
    security_group_ids         = list(string)
    task_exec_iam_role_arn     = string
    task_iam_role_arn          = optional(string)
    target_group_arn           = string
  }))

  default = {}
}

variable "tags" {
  description = "Tags to apply to ECS resources"
  type        = map(string)
  default     = {}
}