aws_region = "us-east-1"

cluster_name = "dev-ecs-cluster"

services = {
  web_app = {
    name            = "dev-web-app-service"
    cpu             = 256
    memory          = 512
    desired_count   = 1

    container_name  = "Main"
    container_image = "public.ecr.aws/docker/library/httpd:latest"
    container_port  = 80

    subnet_ids = [
      "subnet-0cf4fae399fa2f31a",
      "subnet-0d78877cc89ae9c6a"
    ]

    security_group_ids = [
      "sg-0cf9b9cd572c6e3b6"
    ]

    task_exec_iam_role_arn = "arn:aws:iam::027252077505:role/dev-ecs-execution-role-d9bc58ddb245d66bf9df10be23"

    # Our manual deployment did not use a task role.
    # task_iam_role_arn = "REPLACE_WITH_TASK_ROLE_ARN"

    target_group_arn = "arn:aws:elasticloadbalancing:us-east-1:027252077505:targetgroup/dev-748a4f9247f30f5302dcdd2248/6c3d335c9b223fa1"
  }
}

tags = {
  Environment = "dev"
  managedby = "terraform"
}