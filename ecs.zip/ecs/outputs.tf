output "cluster_arn" {
  description = "ARN of the ECS cluster"
  value       = module.ecs.cluster_arn
}

output "cluster_id" {
  description = "ID of the ECS cluster"
  value       = module.ecs.cluster_id
}

output "cluster_name" {
  description = "Name of the ECS cluster"
  value       = module.ecs.cluster_name
}

output "service_arns" {
  description = "ARNs of the ECS services"
  value       = module.ecs.service_arns
}

output "service_names" {
  description = "Names of the ECS services"
  value       = module.ecs.service_names
}