output "cluster_arn" {
  description = "ARN of the ECS cluster"
  value       = module.ecs_cluster.arn
}

output "cluster_id" {
  description = "ID of the ECS cluster"
  value       = module.ecs_cluster.id
}

output "cluster_name" {
  description = "Name of the ECS cluster"
  value       = module.ecs_cluster.name
}

output "service_arns" {
  description = "ARNs of the ECS services"
  value = {
    for service_name, service in module.ecs_service :
    service_name => service.id
  }
}

output "service_names" {
  description = "Names of the ECS services"
  value = {
    for service_name, service in module.ecs_service :
    service_name => service.name
  }
}