module "kafka" {
  source = "../../../modules/kafka"

  cluster_name              = var.cluster_name
  kafka_version             = var.kafka_version
  number_of_broker_nodes    = var.number_of_broker_nodes
  broker_node_instance_type = var.broker_node_instance_type
  volume_size               = var.volume_size

  private_subnet_ids = var.private_subnet_ids
  security_group_ids = var.security_group_ids

  tags = var.tags
}