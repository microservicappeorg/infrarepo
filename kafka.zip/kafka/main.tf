module "kafka" {
  source  = "terraform-aws-modules/msk-kafka-cluster/aws"
  version = "3.3.0"

  name = var.cluster_name

  kafka_version          = var.kafka_version
  number_of_broker_nodes = var.number_of_broker_nodes

  broker_node_instance_type = var.broker_node_instance_type

  broker_node_client_subnets = var.private_subnet_ids
  broker_node_security_groups = var.security_group_ids

  broker_node_storage_info = {
    ebs_storage_info = {
      volume_size = var.volume_size
    }
  }

  encryption_in_transit_client_broker = "TLS"
  encryption_in_transit_in_cluster    = true

  client_authentication = {
    sasl = {
      iam = true
    }
  }

  cloudwatch_logs_enabled = true

  enhanced_monitoring = "DEFAULT"

  tags = var.tags
}