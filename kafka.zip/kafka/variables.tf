variable "cluster_name" {
  description = "Name of the MSK Kafka cluster"
  type        = string
}

variable "kafka_version" {
  description = "Apache Kafka version"
  type        = string
}

variable "number_of_broker_nodes" {
  description = "Number of Kafka broker nodes"
  type        = number
}

variable "broker_node_instance_type" {
  description = "EC2 instance type used for Kafka brokers"
  type        = string
}

variable "volume_size" {
  description = "EBS volume size in GB for each Kafka broker"
  type        = number
}

variable "private_subnet_ids" {
  description = "Private subnet IDs where Kafka brokers will be deployed"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups attached to the Kafka brokers"
  type        = list(string)
}

variable "tags" {
  description = "Tags to apply to MSK resources"
  type        = map(string)
  default     = {}
}