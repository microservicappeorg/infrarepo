variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "cluster_name" {
  description = "Name of the MSK cluster"
  type        = string
}

variable "kafka_version" {
  description = "Apache Kafka version"
  type        = string
}

variable "number_of_broker_nodes" {
  description = "Number of Kafka broker nodes"
  type        = number
}

variable "broker_node_instance_type" {
  description = "Kafka broker instance type"
  type        = string
}

variable "volume_size" {
  description = "Kafka broker EBS volume size in GB"
  type        = number
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Kafka"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups for Kafka"
  type        = list(string)
}

variable "tags" {
  description = "Common resource tags"
  type        = map(string)
  default     = {}
}