aws_region = "us-east-1"

cluster_name = "dev-kafka"

kafka_version = "3.7.x"

number_of_broker_nodes = 2

broker_node_instance_type = "kafka.t3.small"

volume_size = 20

private_subnet_ids = [
  "subnet-0dc585fda13715bfd",
  "subnet-0c37afd7e4e9f2280"
]

security_group_ids = [
  "sg-0ea2017ec5da70712"
]

tags = {
  Environment = "dev"
  Terraform   = true
}