output "cluster_arn" {
  description = "ARN of the MSK cluster"
  value       = module.kafka.cluster_arn
}

output "cluster_name" {
  description = "Name of the MSK cluster"
  value       = module.kafka.cluster_name
}

output "cluster_uuid" {
  description = "UUID of the MSK cluster"
  value       = module.kafka.cluster_uuid
}

output "bootstrap_brokers" {
  description = "Kafka bootstrap broker endpoints"
  value       = module.kafka.bootstrap_brokers
}

output "bootstrap_brokers_vpc_connectivity_sasl_iam" {
  description = "Kafka IAM bootstrap broker endpoints"
  value       = module.kafka.bootstrap_brokers_vpc_connectivity_sasl_iam
}

output "current_version" {
  description = "Current MSK cluster version"
  value       = module.kafka.current_version
}