module "security_group_rules" {
  source = "../../../modules/securitygroup-rules"

  for_each = var.security_group_rules

  security_group_id = each.value.security_group_id
  ingress_rules     = each.value.ingress_rules
  egress_rules      = each.value.egress_rules
}