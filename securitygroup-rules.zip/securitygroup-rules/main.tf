resource "aws_vpc_security_group_ingress_rule" "this" {

  for_each = var.ingress_rules

  security_group_id = var.security_group_id

  from_port   = each.value.from_port
  to_port     = each.value.to_port
  ip_protocol = each.value.ip_protocol

  cidr_ipv4 = try(each.value.cidr_ipv4, null)

  referenced_security_group_id = try(each.value.referenced_security_group_id, null)

  description = try(each.value.description, null)
}


resource "aws_vpc_security_group_egress_rule" "this" {

  for_each = var.egress_rules

  security_group_id = var.security_group_id

  from_port   = each.value.from_port
  to_port     = each.value.to_port
  ip_protocol = each.value.ip_protocol

  cidr_ipv4 = try(each.value.cidr_ipv4, null)

  referenced_security_group_id = try(each.value.referenced_security_group_id, null)

  description = try(each.value.description, null)
}