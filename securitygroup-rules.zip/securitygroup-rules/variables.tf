variable "security_group_rules" {
  type = map(object({
    security_group_id = string
    ingress_rules     = optional(any, {})
    egress_rules      = optional(any, {})
  }))
}

variable "aws_region" {
type = string
}