variable "security_group_id" {
  description = "The ID of the existing Security Group to which the rules will be applied"
  type        = string
}

variable "ingress_rules" {
  description = "Ingress rules to be created for the Security Group"
  type        = any
  default     = {}
}

variable "egress_rules" {
  description = "Egress rules to be created for the Security Group"
  type        = any
  default     = {}
}