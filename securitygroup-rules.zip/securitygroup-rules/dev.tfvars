security_group_rules = {
  alb = {

    security_group_id = "sg-0bd6a60eec0475302"

    ingress_rules = {
      https = {
        from_port   = 443
        to_port     = 443
        ip_protocol = "tcp"
        cidr_ipv4   = "0.0.0.0/0"
        description = "Allow HTTPS traffic from the Internet"
      }
      http = {
        from_port   = 80
        to_port     = 80
        ip_protocol = "tcp"
        cidr_ipv4   = "0.0.0.0/0"
        description = "Allow HTTPS traffic from the Internet"
      }
    }

    egress_rules = {
      https = {
        from_port   = 443
        to_port     = 443
        ip_protocol = "tcp"
        cidr_ipv4   = "0.0.0.0/0"
        description = "Allow HTTPS traffic to the Internet"
      }
    }
  }



  ecs = {

    security_group_id = "sg-0b4caf0e793741ed7"


    ingress_rules = {
     http = {
      from_port   = 80
      to_port     = 80
      ip_protocol = "tcp"
      cidr_ipv4   = "0.0.0.0/0"
      description = "Allow HTTP traffic to ECS task"
    }
  }

    egress_rules = {
      https = {
        from_port   = 443
        to_port     = 443
        ip_protocol = "tcp"
        cidr_ipv4   = "0.0.0.0/0"
        description = "Allow HTTPS traffic to the Internet"
      }
    }
  }
}
aws_region = "us-east-1"