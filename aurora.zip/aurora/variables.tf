variable "name" {
  description = "Name of the Aurora cluster"
  type        = string
}

variable "engine" {
  description = "Aurora database engine"
  type        = string
  default     = "aurora-postgresql"

  validation {
    condition     = var.engine == "aurora-postgresql"
    error_message = "This module is intended for Aurora PostgreSQL."
  }
}

variable "engine_version" {
  description = "Aurora PostgreSQL engine version"
  type        = string
}

variable "database_name" {
  description = "Initial database name"
  type        = string
  default     = null
}

variable "master_username" {
  description = "Master database username"
  type        = string
}

variable "instances" {
  description = "Aurora cluster instances"
  type = map(object({
    instance_class = optional(string)
  }))
}

variable "vpc_id" {
  description = "VPC ID where Aurora will be deployed"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs to use for the Aurora DB subnet group"
  type        = list(string)
}

variable "vpc_security_group_ids" {
  description = "Security groups attached to the Aurora cluster"
  type        = list(string)
}

variable "backup_retention_period" {
  description = "Number of days to retain automated backups"
  type        = number
  default     = 7
}

variable "preferred_backup_window" {
  description = "Preferred daily backup window"
  type        = string
  default     = "03:00-04:00"
}

variable "preferred_maintenance_window" {
  description = "Preferred weekly maintenance window"
  type        = string
  default     = "sun:04:00-sun:05:00"
}

variable "deletion_protection" {
  description = "Whether deletion protection is enabled"
  type        = bool
  default     = false
}

variable "skip_final_snapshot" {
  description = "Whether to skip the final snapshot when destroying Aurora"
  type        = bool
  default     = true
}

variable "apply_immediately" {
  description = "Whether modifications are applied immediately"
  type        = bool
  default     = false
}

variable "enabled_cloudwatch_logs_exports" {
  description = "CloudWatch log types to export"
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags to apply to Aurora resources"
  type        = map(string)
  default     = {}
}