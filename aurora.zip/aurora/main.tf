module "aurora" {
  source = "../../../modules/aurora"

  name = var.name

  engine         = var.engine
  engine_version = var.engine_version

  database_name   = var.database_name
  master_username = var.master_username

  instances = var.instances

  vpc_id             = var.vpc_id
  private_subnet_ids = var.private_subnet_ids

  vpc_security_group_ids = var.vpc_security_group_ids

  backup_retention_period = var.backup_retention_period

  preferred_backup_window      = var.preferred_backup_window
  preferred_maintenance_window = var.preferred_maintenance_window

  deletion_protection = var.deletion_protection
  skip_final_snapshot = var.skip_final_snapshot
  apply_immediately   = var.apply_immediately

  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports

  tags = var.tags
}