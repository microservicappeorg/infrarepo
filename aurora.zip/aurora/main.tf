resource "aws_db_subnet_group" "aurora" {
  name       = "${var.name}-subnet-group"
  subnet_ids = var.private_subnet_ids

  tags = var.tags
}

module "aurora" {
  source  = "terraform-aws-modules/rds-aurora/aws"
  version = "10.3.1"

  name = var.name

  engine         = var.engine
  engine_version = var.engine_version

  database_name   = var.database_name
  master_username = var.master_username

  instances = var.instances

  vpc_id                 = var.vpc_id
  db_subnet_group_name   = aws_db_subnet_group.aurora.name
  vpc_security_group_ids = var.vpc_security_group_ids

  storage_encrypted = true

  manage_master_user_password = true

  backup_retention_period = var.backup_retention_period

  preferred_backup_window      = var.preferred_backup_window
  preferred_maintenance_window = var.preferred_maintenance_window

  deletion_protection = var.deletion_protection
  skip_final_snapshot = var.skip_final_snapshot
  apply_immediately   = var.apply_immediately

  enabled_cloudwatch_logs_exports = var.enabled_cloudwatch_logs_exports

  tags = var.tags
}