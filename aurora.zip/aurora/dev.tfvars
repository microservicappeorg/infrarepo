aws_region = "us-east-1"

name = "dev-aurora"

engine         = "aurora-postgresql"
engine_version = "17.11"

database_name   = "devdb"
master_username = "admin"

vpc_id = "vpc-0b9b0b5bae6000daa"

private_subnet_ids = [
  "subnet-0dc585fda13715bfd",
  "subnet-0c37afd7e4e9f2280"
]

vpc_security_group_ids = [
  "sg-05b6b122e5d3d0baf"
]

instances = {
  writer = {
    instance_class = "db.t4g.medium"
  }
}

backup_retention_period = 7

preferred_backup_window      = "03:00-04:00"
preferred_maintenance_window = "sun:04:00-sun:05:00"

deletion_protection = false
skip_final_snapshot = true
apply_immediately   = true

enabled_cloudwatch_logs_exports = []

tags = {
  Environment = "dev"
  ManagedBy   = "Terraform"
}