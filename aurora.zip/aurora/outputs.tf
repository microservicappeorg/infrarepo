output "cluster_arn" {
  description = "ARN of the Aurora cluster"
  value       = module.aurora.cluster_arn
}

output "cluster_id" {
  description = "ID of the Aurora cluster"
  value       = module.aurora.cluster_id
}

output "cluster_endpoint" {
  description = "Writer endpoint of the Aurora cluster"
  value       = module.aurora.cluster_endpoint
}

output "cluster_reader_endpoint" {
  description = "Reader endpoint of the Aurora cluster"
  value       = module.aurora.cluster_reader_endpoint
}

output "cluster_port" {
  description = "Port of the Aurora cluster"
  value       = module.aurora.cluster_port
}

output "database_name" {
  description = "Database name"
  value       = module.aurora.cluster_database_name
}

output "master_user_secret" {
  description = "Secrets Manager secret containing Aurora master credentials"
  value       = module.aurora.cluster_master_user_secret
  sensitive   = true
}

output "db_subnet_group_name" {
  description = "Name of the Aurora DB subnet group"
  value       = aws_db_subnet_group.aurora.name
}