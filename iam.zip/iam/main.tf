module "iam_role" {
  source = "terraform-aws-modules/iam/aws//modules/iam-role"

  name = var.name

  trust_policy_permissions = var.trust_policy_permissions

  policies = var.policies

  inline_policy_permissions = var.inline_policy_permissions

  tags = var.tags
}