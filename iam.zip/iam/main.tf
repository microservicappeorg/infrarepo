module "iam" {
  source = "../../../modules/iam"

  for_each = var.iam_roles

  name                      = each.value.name
  trust_policy_permissions  = each.value.trust_policy_permissions
  policies                  = each.value.policies
  inline_policy_permissions = each.value.inline_policy_permissions

  tags = var.tags
}