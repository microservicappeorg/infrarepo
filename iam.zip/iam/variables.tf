variable "iam_roles" {
  description = "IAM roles to be created"

  type = map(object({
    name = string

    trust_policy_permissions = any

    policies = optional(map(string), {})

    inline_policy_permissions = optional(any, {})
  }))
}

variable "tags" {
  description = "Tags to apply to IAM resources"

  type    = map(string)
  default = {}
}

variable "aws_region" {
    type = string
}