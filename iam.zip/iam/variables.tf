variable "name" {
  description = "Name of the IAM role"
  type        = string
}

variable "trust_policy_permissions" {
  description = "Trust policy statements defining who can assume the IAM role"
  type        = any
  default     = {}
}

variable "policies" {
  description = "Managed IAM policies to attach to the role"
  type        = map(string)
  default     = {}
}

variable "inline_policy_permissions" {
  description = "Inline IAM policy statements defining permissions for the role"
  type        = any
  default     = {}
}

variable "tags" {
  description = "Tags to apply to the IAM role"
  type        = map(string)
  default     = {}
}