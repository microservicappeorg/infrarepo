output "role_arns" {
  description = "ARNs of the IAM roles"

  value = {
    for role_name, role in module.iam :
    role_name => role.role_arn
  }
}

output "role_names" {
  description = "Names of the IAM roles"

  value = {
    for role_name, role in module.iam :
    role_name => role.role_name
  }
}