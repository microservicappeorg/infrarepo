iam_roles = {

  ecs_execution_role = {

    name = "dev-ecs-execution-role"

    trust_policy_permissions = {

      ECSTasks = {

        actions = [
          "sts:AssumeRole"
        ]

        principals = [
          {
            type = "Service"

            identifiers = [
              "ecs-tasks.amazonaws.com"
            ]
          }
        ]
      }
    }

    policies = {

      ECSTaskExecutionRolePolicy = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
    }
  }
}

tags = {
  Environment = "dev"
  ManagedBy   = "Terraform"
}


aws_region = "us-east-1"