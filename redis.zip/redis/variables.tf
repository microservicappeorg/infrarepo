variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "replication_group_id" {
  description = "ID of the Redis replication group"
  type        = string
}

variable "engine_version" {
  description = "Redis engine version"
  type        = string
}

variable "node_type" {
  description = "ElastiCache Redis node type"
  type        = string
}

variable "num_cache_clusters" {
  description = "Number of Redis cache nodes"
  type        = number
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Redis"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups for Redis"
  type        = list(string)
}

variable "apply_immediately" {
  description = "Whether Redis changes should be applied immediately"
  type        = bool
  default     = false
}

variable "maintenance_window" {
  description = "Redis maintenance window"
  type        = string
  default     = "sun:05:00-sun:06:00"
}

variable "tags" {
  description = "Common resource tags"
  type        = map(string)
  default     = {}
}