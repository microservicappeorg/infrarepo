variable "replication_group_id" {
  description = "ID of the Redis replication group"
  type        = string
}

variable "engine_version" {
  description = "Redis engine version"
  type        = string
}

variable "node_type" {
  description = "ElastiCache Redis node type"
  type        = string
}

variable "num_cache_clusters" {
  description = "Number of cache nodes in the replication group"
  type        = number
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Redis"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups attached to Redis"
  type        = list(string)
}

variable "apply_immediately" {
  description = "Whether Redis modifications should be applied immediately"
  type        = bool
  default     = false
}

variable "maintenance_window" {
  description = "Weekly maintenance window"
  type        = string
  default     = "sun:05:00-sun:06:00"
}

variable "tags" {
  description = "Tags to apply to Redis resources"
  type        = map(string)
  default     = {}
}