module "redis" {
  source = "../../../modules/redis"

  replication_group_id = var.replication_group_id

  engine_version = var.engine_version
  node_type      = var.node_type

  num_cache_clusters = var.num_cache_clusters

  private_subnet_ids = var.private_subnet_ids
  security_group_ids = var.security_group_ids

  apply_immediately = var.apply_immediately
  maintenance_window = var.maintenance_window

  tags = var.tags
}