aws_region = "us-east-1"

replication_group_id = "dev-redis"

engine_version = "7.1"

node_type = "cache.t4g.micro"

num_cache_clusters = 1

private_subnet_ids = [
  "subnet-0dc585fda13715bfd",
  "subnet-0c37afd7e4e9f2280"
]

security_group_ids = [
  "sg-072abba16ac9ce247"
]

apply_immediately = true

maintenance_window = "sun:05:00-sun:06:00"

tags = {
  Environment = "dev"
  Terraform   = true
}