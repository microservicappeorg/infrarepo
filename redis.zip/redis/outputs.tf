output "replication_group_id" {
  description = "Redis replication group ID"
  value       = module.redis.replication_group_id
}

output "replication_group_arn" {
  description = "Redis replication group ARN"
  value       = module.redis.replication_group_arn
}

output "primary_endpoint_address" {
  description = "Primary Redis endpoint"
  value       = module.redis.primary_endpoint_address
}

output "reader_endpoint_address" {
  description = "Redis reader endpoint"
  value       = module.redis.reader_endpoint_address
}

output "port" {
  description = "Redis port"
  value       = module.redis.port
}

output "subnet_group_name" {
  description = "Redis subnet group"
  value       = module.redis.subnet_group_name
}