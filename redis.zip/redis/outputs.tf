output "replication_group_id" {
  description = "ID of the Redis replication group"
  value       = module.redis.replication_group_id
}

output "replication_group_arn" {
  description = "ARN of the Redis replication group"
  value       = module.redis.replication_group_arn
}

output "primary_endpoint_address" {
  description = "Primary Redis endpoint"
  value       = module.redis.replication_group_primary_endpoint_address
}

output "reader_endpoint_address" {
  description = "Reader Redis endpoint"
  value       = module.redis.replication_group_reader_endpoint_address
}

output "port" {
  description = "Redis port"
  value       = module.redis.replication_group_port
}

output "subnet_group_name" {
  description = "Redis subnet group name"
  value       = module.redis.subnet_group_name
}