

module "opensearch" {
  source  = "terraform-aws-modules/opensearch/aws"
  version = "2.11.1"

  create_security_group = false

  domain_name    = var.domain_name
  engine_version = var.engine_version

  cluster_config = {
    instance_type            = var.instance_type
    instance_count           = var.instance_count
    dedicated_master_enabled = var.dedicated_master_enabled
    dedicated_master_type    = var.dedicated_master_type
    dedicated_master_count   = var.dedicated_master_count
  }

  ebs_options = {
    ebs_enabled = true
    volume_size = var.volume_size
    volume_type = var.volume_type
  }

  vpc_options = {
    subnet_ids         = var.private_subnet_ids
    security_group_ids = var.security_group_ids
  }

  advanced_security_options = {
    enabled                        = true
    anonymous_auth_enabled         = false
    internal_user_database_enabled = false

    master_user_options = {
      master_user_arn = var.master_user_arn
    }
  }

  encrypt_at_rest = {
    enabled = true
  }

  node_to_node_encryption = {
    enabled = true
  }

  domain_endpoint_options = {
    enforce_https = true
  }

  tags = var.tags
  
  auto_tune_options = {
  desired_state = "DISABLED"
}

}