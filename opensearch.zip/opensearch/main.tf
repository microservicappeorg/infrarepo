module "opensearch" {
  source = "../../../modules/opensearch"

  domain_name    = var.domain_name
  engine_version = var.engine_version

  instance_type  = var.instance_type
  instance_count = var.instance_count

  volume_size = var.volume_size
  volume_type = var.volume_type

  private_subnet_ids = var.private_subnet_ids
  security_group_ids = var.security_group_ids

  dedicated_master_enabled = var.dedicated_master_enabled
  master_user_arn          = var.master_user_arn

  tags = var.tags
}