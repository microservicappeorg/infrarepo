aws_region = "us-east-1"

domain_name = "dev-opensearch"

engine_version = "OpenSearch_2.19"

instance_type  = "t3.small.search"
instance_count = 2
dedicated_master_enabled = false
master_user_arn = "arn:aws:iam::027252077505:role/ado-terraform-role"
volume_size = 20
volume_type = "gp3"

private_subnet_ids = [
  "subnet-0dc585fda13715bfd",
  "subnet-0c37afd7e4e9f2280"
]

security_group_ids = [
  "sg-0b777a154dbd64aa1"
]

tags = {
  Environment = "dev"
  Terraform   = true
}