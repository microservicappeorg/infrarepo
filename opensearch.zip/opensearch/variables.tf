variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "domain_name" {
  description = "Name of the OpenSearch domain"
  type        = string
}

variable "engine_version" {
  description = "OpenSearch engine version"
  type        = string
}

variable "instance_type" {
  description = "OpenSearch instance type"
  type        = string
}

variable "instance_count" {
  description = "Number of OpenSearch instances"
  type        = number
}

variable "volume_size" {
  description = "EBS volume size in GB"
  type        = number
}

variable "volume_type" {
  description = "EBS volume type"
  type        = string
  default     = "gp3"
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for OpenSearch"
  type        = list(string)
}

variable "security_group_ids" {
  description = "Security groups attached to OpenSearch"
  type        = list(string)
}

variable "tags" {
  description = "Tags to apply to OpenSearch resources"
  type        = map(string)
  default     = {}
}

variable "dedicated_master_enabled" {
  description = "Whether dedicated master nodes are enabled"
  type        = bool
  default     = false
}


variable "master_user_arn" {
  description = "IAM ARN used as the OpenSearch master user"
  type        = string
}