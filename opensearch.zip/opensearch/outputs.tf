output "domain_arn" {
  description = "ARN of the OpenSearch domain"
  value       = module.opensearch.domain_arn
}

output "domain_id" {
  description = "ID of the OpenSearch domain"
  value       = module.opensearch.domain_id
}

output "domain_name" {
  description = "Name of the OpenSearch domain"
  value       = module.opensearch.domain_name
}

output "domain_endpoint" {
  description = "Endpoint of the OpenSearch domain"
  value       = module.opensearch.domain_endpoint
}

output "domain_dashboard_endpoint" {
  description = "OpenSearch Dashboards endpoint"
  value       = module.opensearch.domain_dashboard_endpoint
}